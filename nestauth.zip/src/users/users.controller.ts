import {
  Controller,
  Get,
  Post,
  Body,
  UseGuards,
  Req,
  Param,
} from '@nestjs/common';
import { UsersService } from './users.service';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { Roles } from './decorators/roles.decorator';
import { Role } from './enums/roles.enum';
import { RolesGuard } from '../auth/guards/roles.guard';
import { type Request } from 'express';

@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  // Admin tylko
  @Post()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN)
  create(@Body() body: { email: string; password: string; role?: string }) {
    return this.usersService.createUser(body.email, body.password, body.role);
  }

  // Admin tylko: lista wszystkich użytkowników
  @Get()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN)
  findAll() {
    return this.usersService.findAll();
  }

  // Każdy zalogowany użytkownik może sprawdzić swój profil
  @Get('me')
  @UseGuards(JwtAuthGuard)
  getMe(@Req() req) {
    const userId = (req.user as any).sub; // zakładam, że JWT ma sub = userId
    return this.usersService.findOneById(userId);
  }

  // Admin może pobrać dowolnego użytkownika
  @Get(':id')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN)
  findOne(@Param('id') id: string) {
    return this.usersService.findOneById(id);
  }
}
