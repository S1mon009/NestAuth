export enum Role {
  ADMIN = 'admin',
  USER = 'user',
}
