import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { Log, LogDocument } from './schemas/log.schema';

@Injectable()
export class LogsService {
  constructor(@InjectModel(Log.name) private logModel: Model<LogDocument>) {}

  async createLog(
    userId: string | Types.ObjectId,
    action: string,
    ip?: string,
  ) {
    const log = new this.logModel({ userId, action, ip });
    return log.save();
  }

  async findAll() {
    return this.logModel.find().populate('userId', 'email role').exec();
  }
}
